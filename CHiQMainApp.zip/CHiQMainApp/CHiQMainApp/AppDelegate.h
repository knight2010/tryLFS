//
//  AppDelegate.h
//  CHiQMainApp
//
//  Created by lancewer on 12/22/15.
//  Copyright © 2015 Changhong. All rights reserved.
//

#import <UIKit/UIKit.h>
@class CHSDeviceStatusWindow;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) CHSDeviceStatusWindow *statusWindow;
@end

