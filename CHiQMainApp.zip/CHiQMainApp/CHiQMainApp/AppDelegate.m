//
//  AppDelegate.m
//  CHiQMainApp
//
//  Created by lancewer on 12/22/15.
//  Copyright © 2015 Changhong. All rights reserved.
//

#import "AppDelegate.h"
#import "JLRoutes.h"
#import "CHSRouteProtocol.h"

#import "CHSWatchTVSubAppDelegate.h"
#import "CHSScreenProjectionSubAppDelegate.h"
#import "CHSAppManagementSubAppDelegate.h"
#import "CHSCustomItemDataModel.h"
#import "CHSCustomTabBarViewController.h"
#import "CHSRemoteControllerDelegate.h"
#import "CHSMusicSubAppDelegate.h"
#import "CHSUtils+RouteURL.h"
#import "CHSDeviceManager.h"
#import "CHSDeviceStatusWindow.h"
#import "CHSDeviceManager.h"

//子App的主ViewController的路由地址与其相对应的Delegate之间的映射字典
static NSDictionary<NSString *, id<CHSBaseApp>> *baseRouteViewControllerMappingDict;

@interface AppDelegate ()<TabbarDelegate>

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    self.statusWindow = [[CHSDeviceStatusWindow alloc] init];
    [self buildRouteMappingDict];
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    [self.window setRootViewController:[self buildMainTabBarController]];
    [self.window makeKeyAndVisible];
    // Override point for customization after application launch.
    [JLRoutes addRoute:@"/:baseVC/*" handler:^BOOL(NSDictionary *parameters) {
        NSString *baseVC = parameters[@"baseVC"];
        if ([baseVC isEqualToString:REMOTE_CONTROLLER_BASE_URL]) {
            UIViewController *remoteVC = [[CHSRemoteControllerDelegate sharedInstance] baseViewController];
            [self.window.rootViewController showViewController:remoteVC sender:nil];
            return YES;
        }
        id<CHSBaseApp> delegate = baseRouteViewControllerMappingDict[baseVC];
        CHSCustomTabBarViewController *tabVC = (CHSCustomTabBarViewController *)self.window.rootViewController;
        [tabVC setSelectedIndex:[delegate tabBarIndex]];
        return [delegate handleRouteWithRouteInfo:parameters userInfo:nil];
//        NSArray *pathComponents = parameters[kJLRouteWildcardComponentsKey];
    }];
    
    [[CHSDeviceManager sharedInstance] startIPPService];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<NSString *,id> *)options {
    return [JLRoutes routeURL:url];
}


- (CHSCustomTabBarViewController *)buildMainTabBarController {
    CHSCustomItemDataModel *watchTVTabBarItem = [[CHSCustomItemDataModel alloc] init];
    watchTVTabBarItem.relatedViewController = [[CHSWatchTVSubAppDelegate sharedInstance] baseViewController];
    watchTVTabBarItem.itemName = @"电视";
    watchTVTabBarItem.normalImageName = @"lookTV_Normal_Image";
    watchTVTabBarItem.selectedImageName = @"lookTV_Pressed_Image";
    
    CHSCustomItemDataModel *screenProjectionTabBarItem = [[CHSCustomItemDataModel alloc] init];
    screenProjectionTabBarItem.itemName = @"投屏";
    screenProjectionTabBarItem.relatedViewController = [[CHSScreenProjectionSubAppDelegate sharedInstance] baseViewController];
    screenProjectionTabBarItem.normalImageName = @"mine_Normal_Image";
    screenProjectionTabBarItem.selectedImageName = @"mine_Pressed_Image";
    
    CHSCustomItemDataModel *appManagementTabBarItem = [[CHSCustomItemDataModel alloc] init];
    appManagementTabBarItem.itemName = @"应用";
    appManagementTabBarItem.relatedViewController = [[CHSAppManagementSubAppDelegate sharedInstance] baseViewController];
    appManagementTabBarItem.normalImageName = @"search_Normal_Image";
    appManagementTabBarItem.selectedImageName = @"search_Pressed_Image";
    
    CHSCustomItemDataModel *musicTabBarItem = [[CHSCustomItemDataModel alloc] init];
    musicTabBarItem.itemName = @"音乐";
    musicTabBarItem.relatedViewController = [[CHSMusicSubAppDelegate sharedInstance] baseViewController];
    musicTabBarItem.normalImageName = @"found_Normal_Image";
    musicTabBarItem.selectedImageName = @"found_Pressed_Image";
    
    NSArray *itemsArr = @[watchTVTabBarItem, screenProjectionTabBarItem, appManagementTabBarItem, musicTabBarItem];
    
    CHSCustomTabBarViewController *mainTabBarController = [[CHSCustomTabBarViewController alloc] init:itemsArr tabbarType:TabTypeMiddleBulge];
    mainTabBarController.backgroundImage = [UIImage imageNamed:@"tabbarBackground_Image"];
    mainTabBarController.middleImageBack = [UIImage imageNamed:@"tabbarMiddleCircle_Image"];
    mainTabBarController.middleButtonBackImage = [UIImage imageNamed:@"middleCircleButton_Image"];
    mainTabBarController.tabbarDelegate = self;
    return mainTabBarController;
}

- (void)buildRouteMappingDict {
    NSMutableDictionary *tempDict = [NSMutableDictionary dictionary];
    tempDict[WATCH_TV_BASE_URL] = [CHSWatchTVSubAppDelegate sharedInstance];
    tempDict[SCREEN_PROJECTION_BASE_URL] = [CHSScreenProjectionSubAppDelegate sharedInstance];
    tempDict[APPLICATION_BASE_URL] = [CHSAppManagementSubAppDelegate sharedInstance];
    tempDict[MUSIC_BASE_URL] = [CHSMusicSubAppDelegate sharedInstance];
    baseRouteViewControllerMappingDict = [tempDict copy];
}

#pragma mark - TabbarDelegate
- (void)showRelationMiddleButtonAction {
    //当前未连接电视时，提示用户先连电视
    if ([CHSDeviceManager sharedInstance].currentConnectedDevice.deviceID) {
        [[UIApplication sharedApplication] openURL:[CHSUtils remoteControllerURL]];
        return;
    }
}
@end
